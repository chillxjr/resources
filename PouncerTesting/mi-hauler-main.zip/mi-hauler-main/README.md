# mi-hauler
Hauler Job for QB-Core

## Screenshots
![Spawn Hauler](/images/Screenshot_1.png)
![Get Route To Trailer](/images/Screenshot_2.png)
![Trailer](/images/Screenshot_3.png)
![Trailer](/images/Screenshot_4.png)
![Trailer](/images/Screenshot_4.png)
![Trailer](/images/Screenshot_5.png)
![Store Trailer](/images/Screenshot_6.png)
![Rewards](/images/Screenshot_7.png)
